public class Integer {
    private int value;
    
    public Integer(int value) { }
    
    public Integer(String s) { }

    public static int parseInt(String s) { return 0; }
}