public interface Runnable extends java.lang.Runnable {
}