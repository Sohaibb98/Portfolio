public class System {
    static Io out = new Io();
    static Io in = new Io();
    static void exit() { java.lang.System.exit(1); }
}