//(2)
//
//9
//9
import System;
public class test67 {
    public static int x = 89;
    public static void main(String args[]) {
	int a = x = 9;
	System.out.println(a);
	System.out.println(x);
    }
}