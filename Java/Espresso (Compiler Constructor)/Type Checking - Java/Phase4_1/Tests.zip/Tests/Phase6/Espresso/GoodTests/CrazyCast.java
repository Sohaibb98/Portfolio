//(1)
//
//-42
import System;
public class CrazyCast {
    public static void main(String args[]) {
	int i =(int)( + (double) (- (float) (+ ( (long)( - (int)( - 42 ))))));
	System.out.println(i);
    }
}