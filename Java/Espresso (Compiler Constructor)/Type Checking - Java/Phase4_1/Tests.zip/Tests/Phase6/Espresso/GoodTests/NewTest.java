

import System;

public class NewTest {
    /*    public static int x = 42;
    public int y =48;
    
    public void print() {
	System.out.println(y+x);
    }
    */
    public static void main() {
	//int z = 0;
	System.out.print("Input value for z: ");
	//x = System.out.readInt();
	//new NewTest().print();
	//System.out.println(x+z);
    }

}