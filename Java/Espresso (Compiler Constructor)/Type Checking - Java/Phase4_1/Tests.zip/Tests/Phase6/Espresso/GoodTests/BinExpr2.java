//(1)
//
//40
import System;

class Main {
    public static void main(String args[]) {
	int a, b, c;
	a = 10;
	b = 20;
	
	c = a+(b*3)/2+(a+b)%3;

	System.out.println(c);
    }
}
