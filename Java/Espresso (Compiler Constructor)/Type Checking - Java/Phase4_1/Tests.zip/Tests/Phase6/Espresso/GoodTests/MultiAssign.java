//(4)
//
//99
//99
//99
//99
import System;

class Main {
    public static void main(String args[]) {
	int a,b,c,d,i;
	a=0;
	b=0;
	c=0;
	d=0;
	
	
	for (i=0; i<10000; i++) {
	    a = b = c = d = 99;
	}
	System.out.println(a);
	System.out.println(b);
	System.out.println(c);
	System.out.println(d);
    }
}
