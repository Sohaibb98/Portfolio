//(1)
//
//4950
import System;

class Main {
    public static void main(String args[]) {
	int c = 0;
	for (int i=0; i<100; i++) {
	    c=c+i;
	}
	System.out.println(c);
    }
}
