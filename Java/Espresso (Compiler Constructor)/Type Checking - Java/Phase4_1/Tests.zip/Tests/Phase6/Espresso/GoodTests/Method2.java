//(0)
//
import System;

class Main {

    public static void bar() {
	return;
    }

    public static void main(String args[]) {
	bar();
	
    }
}
