//(1)
//
//15
import System;

class Main {
    public static void main(String args[]) {
	int a = 8;
	int c = 7 + a;
	System.out.println(c);

    }
}
