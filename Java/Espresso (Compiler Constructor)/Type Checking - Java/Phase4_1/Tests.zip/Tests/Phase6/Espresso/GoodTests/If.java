//(1)
//
//67
import System;

class Main {
    public static void main(String args[]) {
	int a = 9;
	int b = 7;
	if (a*6 < b/3*2)
	    System.out.println(a-b);
	else
	    if (a<b)
		System.out.println(b-a);
	    else
	        System.out.println(67);

    }
}
