//(1)
//#5: Operator '&' requires both operands of either integral or boolean type.
class test {
      public static void main() {
	  int a = 55 & true;
      }
}