//(1)
//#7: Non boolean Expression found as test in do-statement.
class test {
    public static void main() {
	do {

	} while (7);
    }
}
