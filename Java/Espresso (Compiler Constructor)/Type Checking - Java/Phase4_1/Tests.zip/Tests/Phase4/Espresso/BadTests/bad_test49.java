//(1)
//#5: Variable expected, found value.
class test {
    public static void main() {
	9++;
    }
}