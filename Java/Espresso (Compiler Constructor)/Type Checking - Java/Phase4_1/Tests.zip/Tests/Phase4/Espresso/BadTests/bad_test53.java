//(1)
//#5: Non boolean Expression found as test in while-statement.
class test {
    public static void main() {
	while (1) ;

    }
}
