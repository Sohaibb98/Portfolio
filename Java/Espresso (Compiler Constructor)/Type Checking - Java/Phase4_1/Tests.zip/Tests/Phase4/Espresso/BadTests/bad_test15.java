//(1)
//#5: Operator '>>' requires left operand of integral type.
class test {
      public static void main() {
	  int a = true >> 66;
      }
}
