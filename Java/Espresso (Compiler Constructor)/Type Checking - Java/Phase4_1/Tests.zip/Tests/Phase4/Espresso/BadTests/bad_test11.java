//(1)
//#5: Operator '&&' requires operands of boolean type.
class test {
      public static void main() {
	  int a = 55 && 88;
      }
}