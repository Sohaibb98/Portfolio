//(1)
//#6: Both right and left hand side operands of operator '&=' must be either of boolean or integer type.
class test {
    public static void main() {
	boolean f;
	f &= 5;
    }
}
