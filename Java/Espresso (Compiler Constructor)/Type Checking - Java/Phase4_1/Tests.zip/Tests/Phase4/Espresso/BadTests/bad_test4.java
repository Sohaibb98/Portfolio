//(1)
//#6: Left hand side operand of operator '>>=' must be of integral type.
class test {
    public static void main() {
	float f;
	f >>= 3;
    }
} 