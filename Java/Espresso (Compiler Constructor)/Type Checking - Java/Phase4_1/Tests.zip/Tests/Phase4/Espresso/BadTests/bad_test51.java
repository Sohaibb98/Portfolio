//(1)
//#6: Cannot apply operator '++' to something of type String.
class test {
    public static void main() {
	String a;
	++a;
    }
}