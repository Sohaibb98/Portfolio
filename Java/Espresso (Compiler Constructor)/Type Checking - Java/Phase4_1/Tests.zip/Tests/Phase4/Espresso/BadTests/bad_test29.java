//(1)
//#5: Non boolean Expression found in for-statement.
class test {
    public static void main() {
	for (;7;);
    }
}