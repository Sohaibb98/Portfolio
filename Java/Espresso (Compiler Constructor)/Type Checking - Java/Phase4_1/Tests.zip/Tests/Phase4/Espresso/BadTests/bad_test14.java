//(1)
//#5: Operator '>>' requires right operand of integer type.
class test {
      public static void main() {
	  int a = 55 >> true;
      }
}
