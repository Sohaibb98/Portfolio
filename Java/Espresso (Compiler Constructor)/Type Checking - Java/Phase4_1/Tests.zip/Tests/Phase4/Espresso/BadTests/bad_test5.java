//(1)
//#6: Right hand side operand of operator '>>=' must be of integer type.
class test {
    public static void main() {
	int f;
	f >>= 3.3;
    }
}