//(1)
//#6: Cannot use class name 'test'. Object name expected in cast.
class test {
      public static void main() {
	  test a;
	  a = (test)test;
      }
}