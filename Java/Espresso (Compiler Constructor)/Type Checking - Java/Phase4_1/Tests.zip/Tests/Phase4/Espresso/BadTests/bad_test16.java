//(1)
//#6: 'a' is not a class name.
class test {
      public static void main() {
	  test a;
	  boolean b = (a instanceof a);
      }
}