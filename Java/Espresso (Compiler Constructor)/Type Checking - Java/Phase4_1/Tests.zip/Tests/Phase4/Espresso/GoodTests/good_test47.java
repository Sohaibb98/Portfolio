
class test {
    public static void main() {
	double a;
	a++;
    }
}
