//(1)
//#5: Non boolean Expression found as test in if-statement.
class test {
    public static void main() {
	if (8) 
	    ;
    }
}