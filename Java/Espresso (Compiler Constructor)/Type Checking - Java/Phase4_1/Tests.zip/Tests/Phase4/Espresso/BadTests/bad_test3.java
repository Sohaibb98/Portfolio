//(1)
//#6: Right hand side operand of operator '+=' must be of numeric type.
class test {
    public static void main() {
	String f;
	f += "Hello";
    }
} 