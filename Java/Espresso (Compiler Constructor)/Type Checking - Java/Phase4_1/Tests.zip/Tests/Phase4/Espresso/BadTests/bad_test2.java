//(1)
//#6: Cannot assign value of type double to variable of type int.
class test {
    public static void main() {
	int f;
	f += 3.4;
    }
} 