//(1)
//#5: Non boolean Expression found as test in ternary expression.
class test {
    public static void main() {
	int a = 8?5:0;
    }
}