//(1)
//#5: Cannot assign value of type double to variable of type int.
class test {
    public static void main() {
	int a = true?5:3.4;
    }
}