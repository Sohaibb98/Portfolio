//(1)
//#6: Switch statement expects value of type int.
class test {
    public static void main() {
	double a;
	switch(a) {
	}
    }
}
