
abstract class Test1{
	int a;
	abstract int f();
}

public abstract class espresso_plus1 extends Test1{
	int b;
	abstract int c();
}
