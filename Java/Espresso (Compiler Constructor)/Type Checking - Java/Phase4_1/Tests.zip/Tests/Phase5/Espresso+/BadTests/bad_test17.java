//(1)
//#4: Method 'foo' does not have a body, or should be declared abstract.
public abstract class K {
    public void foo();
}