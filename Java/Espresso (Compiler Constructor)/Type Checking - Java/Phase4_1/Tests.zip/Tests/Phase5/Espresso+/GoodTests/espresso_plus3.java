abstract class Test{
	
}
public class espresso_plus3 extends Test{
	public int f(){
		return 0;
	}
}
