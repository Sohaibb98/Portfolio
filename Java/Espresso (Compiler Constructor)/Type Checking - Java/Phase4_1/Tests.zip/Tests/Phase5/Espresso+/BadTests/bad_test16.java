//(1)
//#4: Method 'foo' cannot be declared final in an interface.
public abstract interface L {
    public final void foo() ;
}