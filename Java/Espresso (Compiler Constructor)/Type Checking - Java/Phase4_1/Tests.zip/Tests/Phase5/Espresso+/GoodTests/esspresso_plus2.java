abstract class Test1{
	public abstract int f();
}
public class esspresso_plus2 extends Test1 {

	public int f() {
		// TODO Auto-generated method stub
		return 0;
	}

}
