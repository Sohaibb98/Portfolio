//(1)
//#4: Abstract method 'foo' cannot have a body.
public class J {
    public abstract void foo() {
    }
}