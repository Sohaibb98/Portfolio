//(1)
//#6: Class 'D' cannot inherit from final class 'C'.
public final class C {
}

public class D extends C {
}
