//(1)
//#4: Final field 'a' in class 'E' must be initialized.
public class E {
    public final int a;
}
