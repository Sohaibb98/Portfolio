//(1)
//# 'private' and 'public' modifiers cannot be used together.
public class MethodTest2 {
    public private f(){
        
    }
}
