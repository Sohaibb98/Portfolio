//(4)
//#7: Syntax error:
//
//    public void private
//                ^
public class MethodTest3 {
    public void private(int a){
        
    }
}
