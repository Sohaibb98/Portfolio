// Output:
// Result: 67

class Main {
    int main() {
	int a = 9;
	int b = 7;
	if (a*6 < b/3*2)
	    return a-b;
	else
	    if (a<b)
		return b-a;
	    else
		return 67;

    }
}
