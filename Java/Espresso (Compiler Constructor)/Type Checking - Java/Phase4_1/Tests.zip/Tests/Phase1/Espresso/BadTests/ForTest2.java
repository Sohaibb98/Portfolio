//(4)
//#8: Syntax error:
//
//        for (int i=0;i<10)
//                         ^
public class ForTest2 {
    public final int f() {
        for (int i=0;i<10)
            return 0;
    }
}
