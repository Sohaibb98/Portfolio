//(4)
//#6: Syntax error:
//
//public class public
//             ^
public class public ClassTest1 {
    private int a;
    
    int getA() {
	return a;
    }
}
