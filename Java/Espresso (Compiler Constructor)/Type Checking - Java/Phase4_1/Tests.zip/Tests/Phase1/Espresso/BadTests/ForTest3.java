//(1)
//Unexpected end of file.    
public class ForTest3 {
    public static int g() {
	int i=0;
	for (i=0;i<100;i--) {
	    i+=100;
	    return 0;
	}
    }
    