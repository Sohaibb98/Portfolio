// Output:
// Result: 40    
class Main {
    int main() {
	int a, b, c;
	a = 10;
	b = 20;
	
	c = a+(b*3)/2+(a+b)%3;

	return c;
    }
}
