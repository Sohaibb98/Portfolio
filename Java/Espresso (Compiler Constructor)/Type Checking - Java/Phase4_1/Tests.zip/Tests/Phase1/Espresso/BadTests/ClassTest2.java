//(4)
//#6: Syntax error:
//
//public Class
//       ^
public Class ClassTest2 {
    int a;
    int f(){
	a++;
	return a;
    }
}
 