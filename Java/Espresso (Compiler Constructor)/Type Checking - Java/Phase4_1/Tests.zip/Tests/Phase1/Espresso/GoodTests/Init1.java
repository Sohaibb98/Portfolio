// Output:
// Result: 15

class Main {
    int main() {
	int a = 8;
	int c = 7 + a;
	return c;

    }
}
