// Output:
// Result: 12       
class Main {
    int main() {
	return 12;
    }
}
