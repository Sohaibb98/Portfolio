//(4)
//#7: Syntax error:
//
//    public void(
//               ^
public class MethodTest4 {
    public void(a ,int b){
    }
}