//(4)
//#7: Syntax error:
//
//    byte char
//         ^
public class TypeDeclarationTest1 {
    byte char=5;
    int f(){
	
    }
}
