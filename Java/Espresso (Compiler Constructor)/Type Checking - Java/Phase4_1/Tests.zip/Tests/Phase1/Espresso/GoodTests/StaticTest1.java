
public class StaticTest1 {
	static int a;
	
	public static void doSmth() {
		a=10;
	}
	
	private int s=0;
	
	public int doSmth2() {
		return 7;
	}
	
	public final void doSmth3() {
		
	}
}
