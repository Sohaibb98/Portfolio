// Output:
// Result: 4950

class Main {
    int main() {
	int c = 0;
	for (int i=0; i<100; i++) {
	    c=c+i;
	}
	return c;
    }
}
