//(4)
//#9: Syntax error:
//
//        private
//        ^
public class TypeDeclaration2 {
    public int a=0;
    int f() {
        private char c = 'c';
    }
}
