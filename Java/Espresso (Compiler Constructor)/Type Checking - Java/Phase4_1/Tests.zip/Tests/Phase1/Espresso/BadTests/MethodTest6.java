//(4)
//#7: Syntax error:
//
//    public int f(int a, int b) void
//                               ^
public class MethodTest6 {
    public int f(int a, int b) void {
	
    }
}
