// Output:
// Result: 0

class Main {

    void bar() {
	return;
    }

    int main() {
	bar();
	return 0;

    }
}
