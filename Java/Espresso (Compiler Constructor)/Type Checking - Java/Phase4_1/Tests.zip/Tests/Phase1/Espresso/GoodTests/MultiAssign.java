// Output:
// Result: 99
class Main {
    int main() {
	int a,b,c,d;
	for (int i=0; i<10000; i++) 
	    a = b = c = d = 99;
	return a;
    }
}
