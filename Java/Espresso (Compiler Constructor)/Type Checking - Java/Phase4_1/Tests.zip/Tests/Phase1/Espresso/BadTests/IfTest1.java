//(4)
//#9: Syntax error:
//
//        if ()
//            ^
public class IfTest1 {
    public int f() {
        int a=0;
        if () {
            a++;
        }
    }
}
