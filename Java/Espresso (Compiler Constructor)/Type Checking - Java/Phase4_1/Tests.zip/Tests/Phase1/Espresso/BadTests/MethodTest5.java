//(4)
//#7: Syntax error:
//
//    int f(int ,
//              ^
public class MethodTest5 {
    int f(int , char c) {
	
    }
}
