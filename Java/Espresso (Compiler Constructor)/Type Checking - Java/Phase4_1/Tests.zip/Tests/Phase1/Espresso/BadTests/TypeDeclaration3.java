//(4)
//#8: Syntax error:
//
//        public
//        ^
public class TypeDeclaration3 {
    public int a=0, 
        public int b=1;
}
