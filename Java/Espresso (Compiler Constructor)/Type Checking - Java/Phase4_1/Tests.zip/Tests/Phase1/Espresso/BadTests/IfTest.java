//(4)
//#8: Syntax error:
//
//        if (a==1 {
//                 ^
public class IfTest {
    public void f(int a){
        if (a==1 {
                a++;
            }
            }
    }
    