//(4)
//#9: Syntax error:
//
//        while (int
//               ^
public class WhileTest {
    int a=0;
    public int f() {
        while (int a==0){
            a++;
        }
    }
}
