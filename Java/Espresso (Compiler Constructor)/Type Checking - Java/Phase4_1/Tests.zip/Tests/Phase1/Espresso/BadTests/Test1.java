//(4)
//#9: Syntax error:
//
//        a+
//         ^
public class Test1 {
    int a=0;
    void f() {
        a+!=1;
    }
}
