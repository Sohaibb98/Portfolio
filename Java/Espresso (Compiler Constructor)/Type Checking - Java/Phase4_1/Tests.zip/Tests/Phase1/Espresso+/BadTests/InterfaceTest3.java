//(4)
//#10: Syntax error:
//
//interface B extends {
//                    ^
interface A {
    int a;
}

interface B extends {
    int b;
}

public class InterfaceTest3 {
}
