//(4)
//#7: Syntax error:
//
//    public void abstract
//                ^
public abstract class AbstractTest {
    public void abstract int f();
}
