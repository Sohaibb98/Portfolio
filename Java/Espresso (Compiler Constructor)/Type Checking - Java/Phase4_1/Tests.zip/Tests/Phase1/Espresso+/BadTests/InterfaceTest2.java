//(4)
//#10: Syntax error:
//
//interface B implements
//            ^
interface A {
    int a;
}

interface B implements A{
    int b;
}

public class InterfaceTest2 {    
}
