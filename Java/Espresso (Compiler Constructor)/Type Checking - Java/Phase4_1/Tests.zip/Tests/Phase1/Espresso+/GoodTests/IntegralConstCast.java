public class test7 {

    public static void main(String args) {
	byte b;
	short s;
	char c;
	int i;
	long l;
	float f;
	double d;

	b= 60;
	s= 0x7fff;

    }
}
