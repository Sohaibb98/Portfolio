abstract class Abstract {
    abstract void foo() ;
    
    void bar() {
    }

}
