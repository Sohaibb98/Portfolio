abstract class A {
    abstract void foo() ;
}

class B extends A {
    void foo() { }
}

class C extends B {
    void foo() { }
}
