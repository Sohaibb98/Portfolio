//(1)
//#6: Symbol 'b' not declared.
class A {
    void f() {
	int a;
	a = b;
    }
}
