public class GoodSwitch {
    
    void main() {
	int a;
	
	switch (a) {
	case 1: 
	    a++;
	    for (int i =0; i < 10; i++)
		a++;
	    break;
	case 3:   
	    a--;  
	    break;
	case 4:   
	    a++;  
	    break;
	}
        
    }
}
