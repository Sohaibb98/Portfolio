class A {
    void B() {
    }
}

class B extends A {
    B() {
    }

}

class C extends B {
    void B() {
    }
}
