//(1)
//#5: Class 'B' not found.
class A {
    void f() {
        A b = new B();
    }
}
