//(1)
//#5: Method 'g' not found.
class A {
    void f() {
	g(2);
    }
}
