// Assignment5.java
// ----------------
// Error msg:  "Assignment5.java:10: Both right and left hand side operands of operator '^=' must be either of boolean or integer type."

public class Assignment5 {
    void main() {
	int a;
	float b;
	
	b ^= 1.55; // this assignment is not ok
    }
}

