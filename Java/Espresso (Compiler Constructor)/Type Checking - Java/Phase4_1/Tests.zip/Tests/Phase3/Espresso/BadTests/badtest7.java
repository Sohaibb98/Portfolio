//(1)
//#7: Field 'a' already defined.//
public class A {
    int a;
}
public class B extends A {
    int a;
}
