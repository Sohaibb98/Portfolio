
class A {

	// no constructors defined!

}

class B {
	int b = 0;
	A a = new A(b);
}

