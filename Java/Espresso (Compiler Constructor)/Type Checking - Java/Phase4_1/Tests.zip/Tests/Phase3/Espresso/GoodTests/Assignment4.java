// Assignment4.java
// ----------------
// Error msg:  "Assignment4.java::10: Right hand side operand of operator '<<=' must be of numeric type."

public class Assignment4 {
    void main() {
	int a;
	float b;
	
	a <<= 1.3; // this assignment is not ok
    }
}
