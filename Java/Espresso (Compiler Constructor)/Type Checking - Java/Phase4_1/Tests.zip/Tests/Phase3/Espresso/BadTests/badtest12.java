//(1)
//#5: Field 'a' not found.
class A {
    void f() {
	this.a = 10;
    }
}
