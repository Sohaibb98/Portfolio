// Assignment3.java
// ----------------
// Error msg:  "Assignment3.java:10: Left hand side operand of operator '<<=' must be of integer type."

public class Assignment3 {
    void main() {
	int a;
	float b;
	
	b <<= 1; // this assignment is not ok
    }
}
