class A {

    A(int a) {}
}

class B {
	int b = 0;
	A a = new A(b);
}
