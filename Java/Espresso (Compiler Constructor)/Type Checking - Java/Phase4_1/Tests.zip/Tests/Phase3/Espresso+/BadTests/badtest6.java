//(2)
//#5: Class 'B' should be declared abstract; it does not implement
// int f( )
public abstract class A {
    abstract int f();
}
class B extends A {
}
