//(1)
//#4: Class 'B' cannot implement class 'A'.
class A { }
class B implements A { }
