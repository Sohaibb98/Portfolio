//(2)
//#5: Class 'A' should be declared abstract; it does not implement
// void f( )
class A {
    public abstract void f();
}
