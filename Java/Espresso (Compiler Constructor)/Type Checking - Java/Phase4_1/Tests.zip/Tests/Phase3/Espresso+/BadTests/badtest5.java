//(2)
//#5: Class 'B' should be declared abstract; it does not implement
// int f( )
interface A {
    int f();
}
class B implements A {
}
