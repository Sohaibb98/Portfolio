//(1)
//#4: Class 'B' cannot inherit from interface 'A'.
interface A {}
class B extends A {}
