public class System2 {
    static Io2 out = new Io2();
    static Io2 in = new Io2();
    static void exit() { java.lang.System.exit(1); }
}